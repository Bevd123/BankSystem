﻿using ClassLibrary;

namespace Bank
{
    public class Class1
    {
        public List<Konto>

    }
}